package org.albertwavering.project;

public class CountingInteger{
  int val = 1;

  public void CountingInteger(){
    this.val = 1;
  }

  public int getVal(){
    return this.val;
  }

  public void incr(){
    this.val += 1;
  }
}
